--XDisparadores

DROP TRIGGER TG_DomiciliariosId;

DROP TRIGGER TG_ClientesId;


DROP TRIGGER TG_Ordenes_BD;